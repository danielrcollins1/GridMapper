========================================================================
       WIN32 APPLICATION : GridMapper
========================================================================

Version 1.0:

Basic functionality; menu-based tools. Save, open, and print.
Customize grid pixel size. Accept GUI double-click to open. 
Scroll bars, memory bitmap, partial repaint for large maps.
Warning message if memory bitmap fails.

