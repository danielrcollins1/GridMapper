//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GridMapper.rc
//
#define IDC_MYICON                      2
#define IDD_GRIDMAPPER_DIALOG           102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_GRIDMAPPER                  107
#define IDI_SMALL                       108
#define IDC_GRIDMAPPER                  109
#define IDR_MAINFRAME                   128
#define IDD_NEWMAP                      130
#define IDD_SETGRIDSIZE                 135
#define IDC_NEW_WIDTH                   1010
#define IDC_NEW_HEIGHT                  1011
#define IDC_PXLS_PER_SQUARE             1014
#define IDC_DEFAULT                     1018
#define IDM_NEW                         32771
#define IDM_OPEN_MAP                    32772
#define IDM_CLEAR_MAP                   32772
#define IDM_SAVE                        32773
#define IDM_SAVE_AS                     32774
#define IDM_PAGE_SETUP                  32775
#define IDM_PRINT                       32776
#define IDM_FILL_MAP                    32780
#define IDM_FILLED                      32781
#define IDM_FLOOR_FILL                  32781
#define IDM_OPEN_FLOOR                  32782
#define IDM_FLOOR_CLEAR                 32782
#define IDM_STAIRS_NS                   32783
#define IDM_FLOOR_NSTAIRS               32783
#define IDM_STAIRS_EW                   32784
#define IDM_FLOOR_WSTAIRS               32784
#define IDM_OPEN_WALL                   32785
#define IDM_WALL_CLEAR                  32785
#define IDM_CLOSED_WALL                 32786
#define IDM_WALL_FILL                   32786
#define IDM_SINGLE_DOOR                 32787
#define IDM_WALL_SINGLE_DOOR            32787
#define IDM_DOUBLE_DOOR                 32788
#define IDM_WALL_DOUBLE_DOOR            32788
#define IDM_SECRET_DOOR                 32789
#define IDM_WALL_SECRET_DOOR            32789
#define IDM_OPEN                        32791
#define IDM_COPY                        32792
#define IDM_SET_GRID_SIZE               32793
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32794
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
